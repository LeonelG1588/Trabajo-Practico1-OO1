package test;

import modelo.Costo;
import modelo.ItemPedido;
import modelo.Plato;
import modelo.Sistema;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Test {

	public static void main(String[] args) {

		Sistema sistema = new Sistema();
		Costo costos = new Costo(500, 10, 2000, 100000, 5000);

		System.out.println("Test 1");
		System.out.println("Agregar e imprimir Personal");

		try {

			sistema.agregarCajero(
					11111111,
					"Juan",
					"Perez",
					LocalDate.of(1990, 5, 10),
					LocalDate.of(2020, 1, 1),
					"Mañana");

			sistema.agregarCocinero(
					22222222,
					"Ana",
					"Lopez",
					LocalDate.of(1988, 3, 15),
					LocalDate.of(2019, 1, 1),
					"Pastas",
					30000);

			sistema.agregarCajero(
					33333333,
					"Luis",
					"Gomez",
					LocalDate.of(1995, 8, 20),
					LocalDate.of(2022, 6, 1),
					"Noche");

			System.out.println(sistema.getlistPersonal());

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		///System.out.println(sistema.buscarPersonal(33333333).calcularLiquidacion(costos));

		System.out.println("\nTest 3");
		System.out.println("Agregar e imprimir Unidades de Venta");

		try {

			sistema.agregarFoodTruck(
					"FT00000001",
					"Food Uno",
					sistema.getlistPersonal().get(0),
					20,
					"ABC123",
					true);

			sistema.agregarPuestoDesmontable(
					"PU00000001",
					"Puesto Uno",
					sistema.getlistPersonal().get(1),
					15,
					2,
					60);

			sistema.agregarFoodTruck(
					"FT00000002",
					"Food Dos",
					sistema.getlistPersonal().get(2),
					30,
					"XYZ987",
					false);

			System.out.println(sistema.getlistUnidadesVenta());

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		///System.out.println(sistema.buscarUnidad("PU00000001").calculoDeCanon(costos));

		System.out.println("\nTest 4");
		System.out.println("Asignar Personal a Unidades");

		try {

			sistema.buscarUnidad("FT00000001")
					.getListPersonal()
					.add(sistema.getlistPersonal().get(0));

			sistema.buscarUnidad("FT00000001")
					.getListPersonal()
					.add(sistema.getlistPersonal().get(1));

			sistema.buscarUnidad("PU00000001")
					.getListPersonal()
					.add(sistema.getlistPersonal().get(2));

			System.out.println(
					sistema.buscarUnidad("FT00000001")
							.getListPersonal());

			System.out.println(
					sistema.buscarUnidad("PU00000001")
							.getListPersonal());

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		System.out.println("\nTest 5");
		System.out.println("Calcular Canon de Unidades");

		try {

			System.out.println(
					"Canon Food Uno: $"
							+ sistema.buscarUnidad("FT00000001")
									.calculoDeCanon(costos));

			System.out.println(
					"Canon Puesto Uno: $"
							+ sistema.buscarUnidad("PU00000001")
									.calculoDeCanon(costos));

			System.out.println(
					"Canon Food Dos: $"
							+ sistema.buscarUnidad("FT00000002")
									.calculoDeCanon(costos));

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		System.out.println("\nTest 6");
		System.out.println("Agregar e imprimir Festival");

		try {

			sistema.agregarFestival(
					"Festival Gourmet",
					"Verano",
					LocalDate.of(2026, 1, 10),
					LocalDate.of(2026, 1, 20),
					costos,
					sistema.buscarUnidad("FT00000001"));

			System.out.println(sistema.getlistFestivales());

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		System.out.println("\nTest 7");
		System.out.println("Agregar Pedidos");

		try {

			Plato hamburguesa =
					new Plato(1, "Hamburguesa", 15000, 3000);

			Plato pizza =
					new Plato(2, "Pizza", 20000, 5000);

			Plato empanada =
					new Plato(3, "Empanada", 5000, 600);

			List<ItemPedido> items1 = new ArrayList<ItemPedido>();
			items1.add(new ItemPedido(1, hamburguesa, 20));
			items1.add(new ItemPedido(2, pizza, 10));

			List<ItemPedido> items2 = new ArrayList<ItemPedido>();
			items2.add(new ItemPedido(3, empanada, 30));
			items2.add(new ItemPedido(4, pizza, 15));

			List<ItemPedido> items3 = new ArrayList<ItemPedido>();
			items3.add(new ItemPedido(5, hamburguesa, 12));
			items3.add(new ItemPedido(6, empanada, 20));

			sistema.agregarPedido(
					LocalDate.of(2026, 1, 15),
					sistema.buscarFestival("Festival Gourmet"),
					sistema.buscarUnidad("FT00000001"),
					items1);

			sistema.agregarPedido(
					LocalDate.of(2026, 1, 16),
					sistema.buscarFestival("Festival Gourmet"),
					sistema.buscarUnidad("PU00000001"),
					items2);

			sistema.agregarPedido(
					LocalDate.of(2026, 1, 18),
					sistema.buscarFestival("Festival Gourmet"),
					sistema.buscarUnidad("FT00000002"),
					items3);

			System.out.println(sistema.getlistPedidos());

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		System.out.println("\nTest 8");
		System.out.println("Reporte de Recaudacion");

		System.out.println(
				sistema.generarReporteRecaudacion(
						sistema.buscarFestival("Festival Gourmet")));

		System.out.println("\nTest 9");
		System.out.println("Filtro Personal por Fecha de Nacimiento");

		System.out.println(
				sistema.personalFiltrado(
						LocalDate.of(1980, 1, 1),
						LocalDate.of(1993, 12, 31)));

		System.out.println("\nTest 10");
		System.out.println("Rentabilidad Neta Food Uno");

		System.out.println(
				sistema.calcularRentabilidadNeta(
						sistema.buscarUnidad("FT00000001"),costos));

		System.out.println("\nTest 11");
		System.out.println("Rentabilidad Neta Puesto Uno entre Fechas");

		System.out.println(
				sistema.calcularRentabilidadNetaEntreFechas(
						sistema.buscarUnidad("PU00000001"),
						LocalDate.of(2026, 1, 10),
						LocalDate.of(2026, 1, 20),costos));

		System.out.println("\nTest 12");
		System.out.println("Ranking de Unidades");

		System.out.println(sistema.rankingUnidades());

	}
}