package modelo;

import java.time.LocalDate;

import java.util.List;

public class Pedido {
	
	private int id;
	private LocalDate fechaTransaccion;
	private Festival festivalOcurrido;
	private UnidadVenta unidadVenta;
	private List<ItemPedido> listItems;
	
	public Pedido(int id, LocalDate fechaTransaccion, Festival festivalOcurrido, UnidadVenta unidadVenta,List<ItemPedido> listItems) 
	{
		super();
		this.id = id;
		this.fechaTransaccion = fechaTransaccion;
		this.festivalOcurrido = festivalOcurrido;
		this.unidadVenta = unidadVenta;
		this.listItems = listItems;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public LocalDate getFechaTransaccion() {
		return fechaTransaccion;
	}

	public void setFechaTransaccion(LocalDate fechaTransaccion) {
		this.fechaTransaccion = fechaTransaccion;
	}

	public Festival getFestivalOcurrido() {
		return festivalOcurrido;
	}

	public void setFestivalOcurrido(Festival festivalOcurrido) {
		this.festivalOcurrido = festivalOcurrido;
	}

	public UnidadVenta getUnidadVenta() {
		return unidadVenta;
	}

	public void setUnidadVenta(UnidadVenta unidadVenta) {
		this.unidadVenta = unidadVenta;
	}

	public List<ItemPedido> getListItems() {
		return listItems;
	}

	@Override
	public String toString() {
		return "\nPedido [id=" + id + ", fechaTransaccion=" + fechaTransaccion + ", festivalOcurrido=" + festivalOcurrido
				+ ", unidadVenta=" + unidadVenta + ", listItems=" + listItems + "]\n";
	}
	
	public boolean equals(Pedido p) {
		return this.unidadVenta.equals(p.getUnidadVenta()) && this.festivalOcurrido.equals(p.getFestivalOcurrido());
	}
	
	//metodo para calcular el total para el REPORTE VENTA :
	public double totalPedido() {
        double total = 0.0;

        for (ItemPedido item : this.listItems) {
          
            double precioPlato = item.getPlato().getPrecioVenta();
            int cantidad = item.getCantidad();

       
            total = total + (precioPlato * cantidad);
        }

        return total;
    }
	
}
	

	
	
	
	



