package modelo;

public class ReporteVenta {
	private UnidadVenta unidadVenta;
	private double recuadacionTotal;
	
	
	public ReporteVenta(UnidadVenta unidadVenta, double recuadacionTotal) {
		this.unidadVenta = unidadVenta;
		this.recuadacionTotal = recuadacionTotal;
	}


	public UnidadVenta getUnidadVenta() {
		return unidadVenta;
	}


	public void setUnidadVenta(UnidadVenta unidadVenta) {
		this.unidadVenta = unidadVenta;
	}


	public double getRecuadacionTotal() {
		return recuadacionTotal;
	}


	public void setRecuadacionTotal(double recuadacionTotal) {
		this.recuadacionTotal = recuadacionTotal;
	}


	@Override
	public String toString() {
		return "ReporteVenta [unidadVenta=" + unidadVenta + ", recuadacionTotal=" + recuadacionTotal + "]";
	}
	
	public boolean equals(ReporteVenta reporteVenta) {
	    return reporteVenta.getUnidadVenta().equals(this.unidadVenta);
	}



}

