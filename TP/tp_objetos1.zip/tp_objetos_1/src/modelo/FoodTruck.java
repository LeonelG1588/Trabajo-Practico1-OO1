package modelo;



public class FoodTruck extends UnidadVenta {
	
	private String patente;
	private boolean usaElectricidad;
	
	public FoodTruck(int id, String codigo, String nombreComercial, Personal responsable, double superficie,String patente, boolean usaElectricidad) throws Exception {
		super(id,codigo,nombreComercial,responsable,superficie)  ;
		this.patente = patente;
		this.usaElectricidad = usaElectricidad;
	}

	public String getPatente() {
		return patente;
	}

	public void setPatente(String patente) {
		this.patente = patente;
	}

	public boolean isUsaElectricidad() {
		return usaElectricidad;
	}

	public void setUsaElectricidad(boolean usaElectricidad) {
		this.usaElectricidad = usaElectricidad;
	}

	@Override
	public String toString() {
		return "\nFoodTruck ["+super.toString()+"patente=" + patente + ", usaElectricidad=" + usaElectricidad + "]\n";
	}


	//C.U 3
	@Override
	public double calculoDeCanon(Costo costos) {
		
		double canon = getSuperficie() * costos.getCostoSuperficie();
		
		if (usaElectricidad) {
			canon += costos.getPlusElectricidad();
		}
		
		return canon;
	}
	
		
	
//	Cálculo de Canon: Método que devuelve el monto a pagar por una unidad:
//	● Food Truck: (Superficie * $500) + $2000 si requiere conexión eléctrica.
//	● Puesto: (Superficie * $500) - (Tiempo de Montaje * $10).

}

