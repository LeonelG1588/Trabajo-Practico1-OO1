package modelo;



public class ItemPedido {
	private int id;
	private Plato plato;
	private int cantidad;
	
	public ItemPedido(int id, Plato plato, int cantidad) {
		super();
		this.id = id;
		this.plato = plato;
		this.cantidad = cantidad;
	}

	
	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public Plato getPlato() {
		return plato;
	}

	public void setPlato(Plato plato) {
		this.plato = plato;
	}

	public int getCantidad() {
		return cantidad;
	}

	public void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}

	@Override
	public String toString() {
		return "\nItemPedido [id=" + id + ", plato=" + plato + ", cantidad=" + cantidad + "]\n";
	}
	
	
	public boolean equals(ItemPedido itemPedido) {
	    return itemPedido.getPlato().equals(this.plato)
	            && itemPedido.cantidad == this.cantidad;
	}
	



	

}
