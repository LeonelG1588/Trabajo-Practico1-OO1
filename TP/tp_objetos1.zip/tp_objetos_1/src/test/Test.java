package test;

import modelo.Costo;
import modelo.ItemPedido;
import modelo.Plato;
import modelo.Sistema;

import java.time.LocalDate;


public class Test {

	public static void main(String[] args) {

		Sistema sistema = new Sistema();
		Costo costos = new Costo(500, 10, 2000, 100000, 5000);

		System.out.println("Test 1");
		System.out.println("Agregar e imprimir Personal");

		try {
			sistema.agregarCajero(
					11111111,
					"Juan",
					"Perez",
					LocalDate.of(1990, 5, 10),
					LocalDate.of(2020, 1, 1),
					"Mañana");

			sistema.agregarCocinero(
					22222222,
					"Ana",
					"Lopez",
					LocalDate.of(1988, 3, 15),
					LocalDate.of(2019, 1, 1),
					"Pastas",
					30000);

			sistema.agregarCajero(
					33333333,
					"Luis",
					"Gomez",
					LocalDate.of(1995, 8, 20),
					LocalDate.of(2022, 6, 1),
					"Noche");
			
			sistema.agregarCocinero(
					44444444,
					"Carolina",
					"Hernandez",
					LocalDate.of(1990, 5, 25),
					LocalDate.of(2021, 2, 4),
					"Pastas",
					30000);

			System.out.println(sistema.getlistPersonal());
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
			

		System.out.println("\nTest 2");
		System.out.println("Traer Personal");
		
		System.out.println(sistema.buscarPersonal(11111111));
		
		

		System.out.println("\nTest 3");
		System.out.println("Agregar e imprimir Unidades de Venta");

		
		try {
			
			sistema.agregarFoodTruck(
					"FT00000001",
					"Food Uno",
					sistema.getlistPersonal().get(0),
					20,
					"ABC123",
					true);

			sistema.agregarPuestoDesmontable(
				    "PU00000001",
					"Puesto Uno",
					sistema.getlistPersonal().get(1),
					15,
					2,
					60);

			sistema.agregarFoodTruck(
					"FT00000002",
					"Food Dos",
					sistema.getlistPersonal().get(2),
					30,
					"XYZ987",
					false);
			
			sistema.agregarPuestoDesmontable(
					"PU00000002",
					"Puesto Dos",
					sistema.getlistPersonal().get(3),
					17,
					3,
					40);

			System.out.println(sistema.getlistUnidadesVenta());
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
			

		
		
		///System.out.println(sistema.buscarUnidad("PU00000001").calculoDeCanon(costos));

		System.out.println("\nTest 4");
		System.out.println("Asignar Personal a Unidades");

	


			sistema.buscarUnidad("FT00000001")
					.getListPersonal()
					.add(sistema.getlistPersonal().get(1));
			
			sistema.buscarUnidad("PU00000001")
			.getListPersonal()
			.add(sistema.getlistPersonal().get(0));

			sistema.buscarUnidad("PU00000001")
					.getListPersonal()
					.add(sistema.getlistPersonal().get(2));
			
			sistema.buscarUnidad("FT00000002")
			.getListPersonal()
			.add(sistema.getlistPersonal().get(0));
			
			sistema.buscarUnidad("FT00000002")
			.getListPersonal()
			.add(sistema.getlistPersonal().get(1));

			System.out.println(
					sistema.buscarUnidad("FT00000001")
							.getListPersonal());


		
		
		System.out.println("\nTest 5");
		System.out.println("Asignar Platos a Unidades");

		
			
			Plato hamburguesa =
					new Plato(1, "Hamburguesa", 15000, 3000);

			Plato pizza =
					new Plato(2, "Pizza", 20000, 5000);

			Plato empanada =
					new Plato(3, "Empanada", 5000, 600);
			
			sistema.buscarUnidad("FT00000001")
			.getListPlatos().add(hamburguesa);
			
			sistema.buscarUnidad("FT00000002")
			.getListPlatos().add(pizza);
			
			sistema.buscarUnidad("PU00000001")
			.getListPlatos().add(empanada);
			

			System.out.println(
					sistema.buscarUnidad("FT00000001")
							.getListPlatos());


		

		System.out.println("\nTest 6");
		System.out.println("Calcular Canon de Unidades");

		

			System.out.println(
					"Canon Food Uno: $"
							+ sistema.buscarUnidad("FT00000001")
									.calculoDeCanon(costos));

			System.out.println(
					"Canon Puesto Uno: $"
							+ sistema.buscarUnidad("PU00000001")
									.calculoDeCanon(costos));

			System.out.println(
					"Canon Food Dos: $"
							+ sistema.buscarUnidad("FT00000002")
									.calculoDeCanon(costos));

		

		System.out.println("\nTest 7");
		System.out.println("Agregar e imprimir Festival");


			
			sistema.agregarFestival(
					"Festival Gourmet",
					"Verano",
					LocalDate.of(2026, 1, 10),
					LocalDate.of(2026, 1, 20),
					costos);
			
			sistema.agregarFestival(
					"Festival Gourmet 2",
					"Otoño",
					LocalDate.of(2026, 4, 10),
					LocalDate.of(2026, 4, 20),
					costos);

			System.out.println(sistema.getlistFestivales());

		
		System.out.println("\nTest 8");
		System.out.println("Asignar Unidades a Festival");

	

			sistema.buscarFestival("Festival Gourmet")
					.getListUnidades()
					.add(sistema.getlistUnidadesVenta().get(0));
			
			sistema.buscarFestival("Festival Gourmet")
			.getListUnidades()
			.add(sistema.getlistUnidadesVenta().get(1));
			
			sistema.buscarFestival("Festival Gourmet")
			.getListUnidades()
			.add(sistema.getlistUnidadesVenta().get(2));


			System.out.println(
					sistema.buscarFestival("Festival Gourmet")
							.getListUnidades());
		

		System.out.println("\nTest 9");
		System.out.println("Agregar Pedidos");

		try {

			sistema.agregarPedido(
					LocalDate.of(2026, 1, 15),
					sistema.buscarFestival("Festival Gourmet"),
					sistema.buscarUnidad("FT00000001"));

			sistema.agregarPedido(
					LocalDate.of(2026, 1, 16),
					sistema.buscarFestival("Festival Gourmet"),
					sistema.buscarUnidad("PU00000001"));

			sistema.agregarPedido(
					LocalDate.of(2026, 1, 18),
					sistema.buscarFestival("Festival Gourmet"),
					sistema.buscarUnidad("FT00000002"));

			System.out.println(sistema.getlistPedidos());

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		System.out.println("\nTest 10");
		System.out.println("Asignar ItemPedidos a Pedido");

	
			sistema.buscarPedido("Festival Gourmet","FT00000001")
		       .getListItems()
		       .add(new ItemPedido(1, hamburguesa, 24));
			
			sistema.buscarPedido("Festival Gourmet","FT00000001")
		       .getListItems()
		       .add(new ItemPedido(2, pizza, 30));
			
			sistema.buscarPedido("Festival Gourmet","FT00000002")
		       .getListItems()
		       .add(new ItemPedido(2, pizza, 42));
			
			sistema.buscarPedido("Festival Gourmet","PU00000001")
		       .getListItems()
		       .add(new ItemPedido(3, empanada, 72));
			
			System.out.println(
					sistema.buscarPedido("Festival Gourmet","FT00000001").getListItems());
							

		System.out.println("\nTest 11");
		System.out.println("Reporte de Recaudacion");

		System.out.println(
				sistema.generarReporteRecaudacion(
						sistema.buscarFestival("Festival Gourmet")));

		System.out.println("\nTest 12");
		System.out.println("Filtro Personal por Fecha de Nacimiento");

		System.out.println(
				sistema.personalFiltrado(
						LocalDate.of(1980, 1, 1),
						LocalDate.of(1993, 12, 31)));

		System.out.println("\nTest 13");
		System.out.println("Rentabilidad Neta Food Uno");

		System.out.println("$"+
				sistema.calcularRentabilidadNeta(
						sistema.buscarUnidad("FT00000001"),costos));

		System.out.println("\nTest 14");
		System.out.println("Rentabilidad Neta Puesto Uno entre Fechas");

		System.out.println("$"+
				sistema.calcularRentabilidadNetaEntreFechas(
						sistema.buscarUnidad("PU00000001"),
						LocalDate.of(2026, 1, 10),
						LocalDate.of(2026, 1, 20),costos));

		System.out.println("\nTest 15");
		System.out.println("Ranking de Unidades");

		System.out.println(sistema.rankingUnidades());
		
		System.out.println("\nTest 16");
		System.out.println("Plato Estrella");
		System.out.println(sistema.platoEstrella(sistema.buscarUnidad("FT00000001"),sistema.buscarFestival("Festival Gourmet")));
		
		System.out.println("\nTest 17");
		System.out.println("Auditoria de Personal del Festival");
		System.out.println(sistema.traerAuditoriaPersonalFestival("Festival Gourmet"));
		
		System.out.println("\nTest 18");
		System.out.println(" Unidades con Mayor Canon");
		System.out.println();
		
		System.out.println("\nTest 19");
		System.out.println("Agregar Personal menor de edad");
		
		try {
			sistema.agregarCajero(
					55555555,
					"Roberto",
					"Fernandez",
					LocalDate.of(2012, 5, 10),
					LocalDate.of(2020, 1, 1),
					"Mañana");

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		System.out.println("\nTest 19");
		System.out.println("Agregar Unidad con un codigo mayor de 10 caracteres");
		
		try {
			sistema.agregarFoodTruck(
					"FT000000011",
					"Food 1",
					sistema.getlistPersonal().get(0),
					20,
					"ABC123",
					true);

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		System.out.println("\nTest 20");
		System.out.println("Dar de baja un Personal");
		System.out.println(sistema.eliminarPersonal(44444444));
		
		System.out.println("\nTest 21");
		System.out.println("Dar de baja una Unidad");
		System.out.println(sistema.eliminarUnidadVenta("PU00000002"));
		
		System.out.println("\nTest 22");
		System.out.println("Dar de baja un Festival");
		System.out.println(sistema.eliminarFestival("Festival Gourmet 2"));
		
		
		
		

	}
}