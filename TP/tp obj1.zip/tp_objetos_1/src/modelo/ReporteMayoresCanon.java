package modelo;

public class ReporteMayoresCanon {
	private UnidadVenta unidadVenta;
	private double canon;
	
	public ReporteMayoresCanon(UnidadVenta unidadVenta, double canon) {
		this.unidadVenta = unidadVenta;
		this.canon = canon;
	}


	public UnidadVenta getUnidadVenta() {
		return unidadVenta;
	}


	public void setUnidadVenta(UnidadVenta unidadVenta) {
		this.unidadVenta = unidadVenta;
	}


	public double getCanon() {
		return canon;
	}


	public void setCanon(double canon) {
		this.canon = canon;
	}
	
	public boolean equals(ReporteMayoresCanon reporte) {
	    return reporte.getUnidadVenta().equals(this.unidadVenta);
	}
	
	@Override
	public String toString() {
		// Averiguamos el tipo de unidad para cumplir con lo que pide el CU 13
		String tipo = "";
		if (this.unidadVenta instanceof FoodTruck) {
			tipo = "FoodTruck";
		} else if (this.unidadVenta instanceof PuestoDesarmable) {
			tipo = "PuestoDesarmable";
		}
		
		// Retornamos el String armado (asegurate de tener los getters en UnidadVenta)
		return "Reporte [Unidad: " + this.unidadVenta.getNombreComercial() + 
		       ", Código: " + this.unidadVenta.getCodigo() + 
		       ", Tipo: " + tipo + 
		       ", Canon: $" + this.canon + "]";
	}

}
