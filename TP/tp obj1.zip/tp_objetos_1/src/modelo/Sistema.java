package modelo;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Sistema {
	private List<Pedido> listPedidos;
	private List<UnidadVenta> listUnidades;
	private List<Personal> listPersonal;
	private List<Festival> listFestivales;
	
	
	public Sistema() {
		super();
		this.listUnidades=new ArrayList<UnidadVenta>();
		this.listPersonal= new ArrayList<Personal>();
		this.listFestivales = new ArrayList <Festival>();
		this.listPedidos = new ArrayList <Pedido>();
	}
	
	public List<Personal> getlistPersonal() {
		return listPersonal;
	}
	public List<UnidadVenta> getlistUnidadesVenta() {
		return listUnidades;
	}
	public List<Festival> getlistFestivales(){
		return listFestivales;
	}
	public List <Pedido> getlistPedidos(){
		return listPedidos;
	}
	
	
	//CASO DE USO N1
	public boolean agregarCajero(long dni, String nombre, String apellido, LocalDate fechaNacimiento, LocalDate fechaIngreso,
			String turno) throws Exception {
		
		int id;
		
		if(!listPersonal.isEmpty()) {
			id = listPersonal.get(listPersonal.size() -1).getId() +1;
		} else {
			id = 1;
		}
		
		
		Personal nuevoCajero = new Cajero(id,dni,nombre,apellido,fechaNacimiento,fechaIngreso,
				turno);
		
		
		
		return listPersonal.add(nuevoCajero);
	}
	
	public boolean agregarCocinero(long dni, String nombre, String apellido, LocalDate fechaNacimiento, LocalDate fechaIngreso,
			String especialidad, double plusFijo) throws Exception {
		
		int id;
		
		if(!listPersonal.isEmpty()) {
			id = listPersonal.get(listPersonal.size() -1).getId() +1;
		} else {
			id = 1;
		}
		
		Personal nuevoCocinero = new Cocinero(id,dni,nombre,apellido,fechaNacimiento,fechaIngreso,especialidad,plusFijo);
		
		
		return listPersonal.add(nuevoCocinero);
	}
	
	public boolean eliminarPersonal(long dni) {
		
		Personal p = buscarPersonal(dni);
		boolean eliminado = false;
		if (p != null) {
			eliminado = true;
			listPersonal.remove(p);
		}
		
		return eliminado;
		
	}
	
	public boolean agregarFoodTruck(String codigo, String nombreComercial, Personal responsable, double superficie, String patente, boolean usaElectricidad) throws Exception {
		int id = 1;
		if (!this.listUnidades.isEmpty()) {
			id = this.listUnidades.get(this.listUnidades.size() - 1).getId() + 1;
		}
		UnidadVenta nuevoFoodTruck = new FoodTruck(id, codigo, nombreComercial, responsable, superficie, patente, usaElectricidad);
		return this.listUnidades.add(nuevoFoodTruck);
	}

	public boolean agregarPuestoDesmontable(String codigo, String nombreComercial, Personal responsable, double superficie, int cantidadCarpas, int tiempoMontaje) throws Exception {
		int id = 1;
		if (!this.listUnidades.isEmpty()) {
			id = this.listUnidades.get(this.listUnidades.size() - 1).getId() + 1;
		}
		UnidadVenta nuevoPuesto = new PuestoDesarmable(id, codigo, nombreComercial, responsable, superficie, cantidadCarpas, tiempoMontaje);

		return this.listUnidades.add(nuevoPuesto);
	}
	
	public boolean eliminarUnidadVenta(String codigo) {
		UnidadVenta u = buscarUnidad(codigo);
		boolean eliminado = false;
		if(u != null) {
			eliminado = true;
			listUnidades.remove(u);
		}
		return eliminado;
	}
	
	public boolean agregarFestival(String nombre, String temporada, LocalDate fechaInicio, LocalDate fechaFinal,Costo costos) { 
		int id = 1; 

		if (!this.listFestivales.isEmpty()){
			id = this.listFestivales.get(this.listFestivales.size()-1).getId()+1;	
		}
		Festival nuevoFestival = new Festival(id, nombre, temporada, fechaInicio, fechaFinal,costos);
		return listFestivales.add(nuevoFestival); 
	}
	
	public boolean eliminarFestival(String nombre) {
		Festival f = buscarFestival(nombre);
		boolean eliminado = false;
		if(f != null) {
			eliminado = true;
			listFestivales.remove(f);
		}
		return eliminado;
	}
	
	
	//CASO DE USO N2
	public Personal buscarPersonal(long dni) {
	    Personal p = null;
	    
	    int i = 0;
	    
	    while (i < listPersonal.size() && p == null) {
	        if (listPersonal.get(i).getDni() == dni) {
	            p = listPersonal.get(i);
	        }
	        i++;
	    }
	    return p;
	}
	
	
	
	//CASO DE USO N2.1
	public UnidadVenta buscarUnidad(String codigo) {
		UnidadVenta u = null;
		int i = 0;
		
		while (i < listUnidades.size() && u == null) {
			if (listUnidades.get(i).getCodigo().trim().equals(codigo.trim())) {
				u = listUnidades.get(i);
			}
			i++;
		}
		return u;
	}
	
	
	//CASO DE USO N2.2
	public Festival buscarFestival(String nombre) {
		Festival f = null;
		int i = 0;
		
		while (i < listFestivales.size() && f == null) {
			if (listFestivales.get(i).getNombre().trim().equals(nombre.trim())) {
				f = listFestivales.get(i);
			}
			i++;
		}
		return f;
	}
	
	//CASO DE USO N2.3 
	public Pedido buscarPedido(String nombre ,String codigo) {
		Pedido p = null;
		int i = 0;
		
		while(i < listPedidos.size() && p == null) {
			if(listPedidos.get(i).getFestivalOcurrido().getNombre().equalsIgnoreCase(nombre) && listPedidos.get(i).getUnidadVenta().getCodigo().equalsIgnoreCase(codigo)) {
				p = listPedidos.get(i);
			}
			i++;
		}
		
		return p;
	}
	
	
	//CASO DE USO N5
	public boolean agregarPedido(LocalDate fechaTransaccion, Festival festivalOcurrido,UnidadVenta unidadVenta) 
			throws Exception {
		if(buscarUnidad(unidadVenta.getCodigo()) == null || buscarFestival(festivalOcurrido.getNombre()) == null) {
			throw new Exception("Excepcion: La unidad o el festival no existe");
		}
		
        int id = 1;

        if (!this.listPedidos.isEmpty())
            id = this.listPedidos.get(this.listPedidos.size() - 1).getId() + 1;

        Pedido pedido = new Pedido(id,fechaTransaccion, festivalOcurrido,unidadVenta);
        return this.listPedidos.add(pedido);
                
    }
	
	//CU 6 
	public List<ReporteVenta> generarReporteRecaudacion(Festival festival) {
		List<ReporteVenta> reporteFinal = new ArrayList<ReporteVenta>();

		for (UnidadVenta unidad : this.listUnidades) {

			double sumaRecaudacion = 0.0;

			for (Pedido pedido : this.listPedidos) {

				if (festival.equals(pedido.getFestivalOcurrido()) && pedido.getUnidadVenta().equals(unidad)) {
					sumaRecaudacion = sumaRecaudacion + pedido.totalPedido();
				}
			}

			ReporteVenta unReporte = new ReporteVenta(unidad, sumaRecaudacion);
			reporteFinal.add(unReporte);
		}
		return reporteFinal;
	}
	
	//CU 7
	public List<Personal> personalFiltrado(LocalDate fechaDesde, LocalDate fechaHasta){
		List<Personal> aux = new ArrayList<>();

		for (Personal p : listPersonal) {
			if ((p.getFechaNacimiento().isEqual(fechaDesde) || p.getFechaNacimiento().isAfter(fechaDesde)) && 
	                (p.getFechaNacimiento().isEqual(fechaHasta) || p.getFechaNacimiento().isBefore(fechaHasta))) {
				aux.add(p);
			}
		}
		return aux;
	}
	
	//CU 8
		public double calcularRentabilidadNeta(UnidadVenta unidad,Costo costos) {

		    double rentabilidad = 0;

		    if (unidad != null) {

		        double totalVentas = 0;
		        double costoPlatos = 0;
		        double costoSueldos = 0;

		        for (Pedido pedido : this.listPedidos) {

		            if (pedido.getUnidadVenta().equals(unidad)) {

		                totalVentas += pedido.totalPedido();

		                for (ItemPedido item : pedido.getListItems()) {

		                    costoPlatos += item.getPlato().getCostoProduccion()
		                                  * item.getCantidad();
		                }
		            }
		        }

		        for (Personal personal : unidad.getListPersonal()) {
		            costoSueldos += personal.calcularLiquidacion(costos);
		        }

		        double canon = unidad.calculoDeCanon(costos);
		        
		       

		        rentabilidad = totalVentas - costoPlatos - costoSueldos - canon;
		    }

		    return rentabilidad;
		}
	//CU 9
	public double calcularRentabilidadNetaEntreFechas(UnidadVenta unidad,LocalDate fechaDesde,LocalDate fechaHasta,Costo costos) {

		    double ventas = 0;
		    double costoPlatos = 0;
		    double costoSueldos = 0;
		    double rentabilidad = 0;

		    for (Pedido p : this.listPedidos) {

		        if (p.getUnidadVenta().equals(unidad)
		                && (p.getFechaTransaccion().isEqual(fechaDesde)|| p.getFechaTransaccion().isAfter(fechaDesde))
		                && (p.getFechaTransaccion().isEqual(fechaHasta)|| p.getFechaTransaccion().isBefore(fechaHasta))) {

		            ventas = ventas + p.totalPedido();

		            for (ItemPedido item : p.getListItems()) {

		                costoPlatos = costoPlatos
		                        + (item.getCantidad()
		                        * item.getPlato().getCostoProduccion());
		            }
		        }
		    }

		    for (Personal personal : unidad.getListPersonal()) {

		        costoSueldos = costoSueldos
		                + personal.calcularLiquidacion(costos);
		    }

		    rentabilidad = ventas - costoPlatos - costoSueldos- unidad.calculoDeCanon(costos);

		    return rentabilidad;
		}
	//CU 10
	public List<ReporteVenta> rankingUnidades() {

		List<ReporteVenta> ranking = new ArrayList<ReporteVenta>();

		    for (UnidadVenta unidad : this.listUnidades) {

		        double recaudacion = 0;

		        for (Pedido pedido : this.listPedidos) {

		            if (pedido.getUnidadVenta().equals(unidad)) {

		                recaudacion = recaudacion + pedido.totalPedido();
		            }
		        }

		        ranking.add(new ReporteVenta(unidad, recaudacion));
		    }

		    for (int i = 0; i < ranking.size(); i++) {

		        for (int j = i + 1; j < ranking.size(); j++) {

		            if (ranking.get(j).getRecuadacionTotal()
		                    > ranking.get(i).getRecuadacionTotal()) {

		                ReporteVenta aux = ranking.get(i);
		                ranking.set(i, ranking.get(j));
		                ranking.set(j, aux);
		            }
		        }
		    }

		    return ranking;
		}
	
	//CU 11
	public Plato platoEstrella(UnidadVenta unidad, Festival festival) {

		List<Plato> platosAux = new ArrayList<>();

		for (Pedido pedido : listPedidos) {
			if (unidad.equals(pedido.getUnidadVenta()) && festival.equals(pedido.getFestivalOcurrido())) {
				for (ItemPedido item : pedido.getListItems()) {
					Plato p = item.getPlato();

					if (!platosAux.contains(p)) {
						platosAux.add(p);
					}
				}
			}
		}
		Plato platoEstrella = null;
		int maxCantidad = 0; 

		for (Plato platoActual : platosAux) {
			int cantidadTotalPlatos = 0;

			for (Pedido pedido : listPedidos) {
				if (unidad.equals(pedido.getUnidadVenta()) && festival.equals(pedido.getFestivalOcurrido())) {
					for (ItemPedido item : pedido.getListItems()) {
						if (item.getPlato().equals(platoActual)) {
							cantidadTotalPlatos += item.getCantidad();
						}
					}
				}
			}	
			
		    
			if (cantidadTotalPlatos > maxCantidad) {
				maxCantidad = cantidadTotalPlatos;
				platoEstrella = platoActual;
			}

		}

		return platoEstrella;	 
	}



	//CU 12
	public List<Personal> traerAuditoriaPersonalFestival(String nombreFestival) {

	    List<Personal> personalAuditado = new ArrayList<>();

	    Festival festival = buscarFestival(nombreFestival);

	    if (festival != null) {

	        for (UnidadVenta unidad : festival.getListUnidades()) {

	            if (!personalAuditado.contains(unidad.getResponsable())) {
	                personalAuditado.add(unidad.getResponsable());
	            }

	            for (Personal p : unidad.getListPersonal()) {

	                if (!personalAuditado.contains(p)) {
	                    personalAuditado.add(p);
	                }
	            }
	        }
	    }

	    return personalAuditado;
	}
	public List<ReporteMayoresCanon> traerUnidadesMayorCanon(String nombreFestival) {

	
		Festival festival = buscarFestival(nombreFestival); 
		
		if (festival == null) {
			return null; 
		}
		
	
		Costo costos = festival.getCostos(); 

		
		List<ReporteMayoresCanon> reportes = new ArrayList<ReporteMayoresCanon>();

		
		for (UnidadVenta unidad : festival.getListUnidades()) { 
			double canon = unidad.calculoDeCanon(costos);
			reportes.add(new ReporteMayoresCanon(unidad, canon));
		}

	
		for (int i = 0; i < reportes.size(); i++) {
			for (int j = i + 1; j < reportes.size(); j++) {
				if (reportes.get(j).getCanon() > reportes.get(i).getCanon()) {
					ReporteMayoresCanon aux = reportes.get(i);
					reportes.set(i, reportes.get(j));
					reportes.set(j, aux);
				}
			}
		}

	
		List<ReporteMayoresCanon> top3 = new ArrayList<ReporteMayoresCanon>();
		for (int i = 0; i < reportes.size() && i < 3; i++) {
			top3.add(reportes.get(i));
		}

	
		return top3;
	}
	
}
