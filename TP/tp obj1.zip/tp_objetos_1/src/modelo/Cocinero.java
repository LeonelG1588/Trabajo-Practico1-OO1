package modelo;

import java.time.LocalDate;



public class Cocinero extends Personal {

	private String especialidad;
	private double plusSueldo;
	
	public Cocinero(int id, long dni, String nombre, String apellido, LocalDate fechaNacimiento, LocalDate fechaIngreso,
			String especialidad, double plusSueldo) throws Exception  {
		super(id,dni,nombre,apellido,fechaNacimiento,fechaIngreso);
		this.especialidad = especialidad;
		this.plusSueldo = plusSueldo;
	}

	public String getEspecialidad() {
		return especialidad;
	}

	public void setEspecialidad(String especialidad) {
		this.especialidad = especialidad;
	}

	public double getPlusSueldo() {
		return plusSueldo;
	}

	public void setPlusSueldo(double plusSueldo) {
		this.plusSueldo = plusSueldo;
	}

	@Override
	public String toString() {
		return "\nCocinero ["+ super.toString()+"especialidad=" + especialidad + ", plusSueldo=" + plusSueldo + "]";
	}
	
	

	//CASO DE USO N4
	@Override
	public double calcularLiquidacion(Costo costos) {
		return costos.getCostoSueldoBase() + plusSueldo;
	}
	
}
	
	
	                                         
	


