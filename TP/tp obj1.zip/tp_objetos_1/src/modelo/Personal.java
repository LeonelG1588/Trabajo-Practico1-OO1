package modelo;

import java.time.LocalDate;




public abstract class Personal {
	protected int id;
	protected long dni;
	protected String nombre;
	protected String apellido;
	protected LocalDate fechaNacimiento;
	protected LocalDate fechaIngreso;
	
	public Personal(int id, long dni, String nombre, String apellido, LocalDate fechaNacimiento, LocalDate fechaIngreso) throws Exception {
		super();
		this.id = id;
		this.dni = dni;
		this.nombre = nombre;
		this.apellido = apellido;
		setFechaNacimiento(fechaNacimiento);
		this.fechaIngreso = fechaIngreso;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public long getDni() {
		return dni;
	}

	public void setDni(long dni) {
		this.dni = dni;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public LocalDate getFechaNacimiento() {
		return fechaNacimiento;
	}
	public void setFechaNacimiento(LocalDate fechaNacimiento) throws Exception {
	    if (fechaNacimiento.plusYears(18).isAfter(LocalDate.now())) {
	        throw new Exception("Error: El empleado debe ser mayor de edad (18 años o más).");
	    }
	    this.fechaNacimiento = fechaNacimiento;
	}

	public LocalDate getFechaIngreso() {
		return fechaIngreso;
	}

	public void setFechaIngreso(LocalDate fechaIngreso) {
		this.fechaIngreso = fechaIngreso;
	}


	@Override
	public String toString() {
		return "\nPersonal [id=" + id + ", dni=" + dni + ", nombre=" + nombre + ", apellido=" + apellido
				+ ", fechaNacimiento=" + fechaNacimiento + ", fechaIngreso=" + fechaIngreso + "]";
	}
	
	
	public boolean equals(Personal personal ) {
		return personal.getDni() == this.dni;
	}

	//CASO DE USO para calcular la antiguedad
		public int calcularAntiguedad() {
			LocalDate hoy = LocalDate.now();
			
			int antiguedad = hoy.getYear() - fechaIngreso.getYear();
			
			if(hoy.getDayOfYear() < fechaIngreso.getDayOfYear()) {
				antiguedad --;
			}
			
			return antiguedad;
		}
		
		
		//CASO DE USO N4
		public abstract double calcularLiquidacion(Costo costos);
		
}

