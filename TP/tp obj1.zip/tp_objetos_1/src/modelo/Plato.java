package modelo;

public class Plato {
	
	private int id; 
	private String nombre;
	private double precioVenta;
	private double costoProduccion;
	
	public Plato(int id, String nombre, double precioVenta, double costoProduccion) {
		super();
		this.id = id;
		this.nombre = nombre;
		this.precioVenta = precioVenta;
		this.costoProduccion = costoProduccion;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public double getPrecioVenta() {
		return precioVenta;
	}

	public void setPrecioVenta(double precioVenta) {
		this.precioVenta = precioVenta;
	}

	public double getCostoProduccion() {
		return costoProduccion;
	}

	public void setCostoProduccion(double costoProduccion) {
		this.costoProduccion = costoProduccion;
	}

	@Override
	public String toString() {
		return "\nPlato [id=" + id + ", nombre=" + nombre + ", precioVenta=" + precioVenta + ", costoProduccion="
				+ costoProduccion + "]";
	}

	public boolean equals(Plato plato) {
		    return plato.getNombre().equals(this.nombre);
		}
}	
	

