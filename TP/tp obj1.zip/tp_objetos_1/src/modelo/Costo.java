package modelo;



public class Costo {
	private double costoSuperficie;
	private double costoMontaje;
	private double plusElectricidad;
	private double costoSueldoBase;
	private double costoAntiguedad;

	public Costo(double costoSuperficie, double costoMontaje, double plusElectricidad, double costoSueldoBase,
			double costoAntiguedad) {
		super();
		this.costoSuperficie = costoSuperficie;
		this.costoMontaje = costoMontaje;
		this.plusElectricidad = plusElectricidad;
		this.costoSueldoBase = costoSueldoBase;
		this.costoAntiguedad = costoAntiguedad;
	}
	
	

	public double getCostoSuperficie() {
		return costoSuperficie;
	}



	public void setCostoSuperficie(double costoSuperficie) {
		this.costoSuperficie = costoSuperficie;
	}



	public double getCostoMontaje() {
		return costoMontaje;
	}



	public void setCostoMontaje(double costoMontaje) {
		this.costoMontaje = costoMontaje;
	}



	public double getPlusElectricidad() {
		return plusElectricidad;
	}



	public void setPlusElectricidad(double plusElectricidad) {
		this.plusElectricidad = plusElectricidad;
	}



	public double getCostoSueldoBase() {
		return costoSueldoBase;
	}



	public void setCostoSueldoBase(double costoSueldoBase) {
		this.costoSueldoBase = costoSueldoBase;
	}
	
	

	
	public double getCostoAntiguedad() {
		return costoAntiguedad;
	}



	public void setCostoAntiguedad(double costoAntiguedad) {
		this.costoAntiguedad = costoAntiguedad;
	}


	
	@Override
	public String toString() {
		return "\nCosto [costoSuperficie=" + costoSuperficie + ", costoMontaje=" + costoMontaje + ", plusElectricidad="
				+ plusElectricidad + ", costoSueldoBase=" + costoSueldoBase + ", costoAntiguedad=" + costoAntiguedad
				+ "]";
	}



	public boolean equals(Costo costo) {
	    return costo.costoSuperficie == this.getCostoSuperficie()
	            && costo.costoMontaje == this.getCostoMontaje()
	            && costo.plusElectricidad == this.getPlusElectricidad()
	            && costo.costoSueldoBase == this.getCostoSueldoBase()
	            && costo.costoAntiguedad == this.getCostoAntiguedad();
	}
}



