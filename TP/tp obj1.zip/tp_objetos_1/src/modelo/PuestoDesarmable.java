package modelo;

public class PuestoDesarmable extends UnidadVenta{
	
	private int cantidadCarpas;
	private int tiempoMontaje;
	
	
	public PuestoDesarmable(int id, String codigo, String nombreComercial, Personal responsable, double superficie,int cantidadCarpas, int tiempoMontaje) throws Exception {
		super(id,codigo,nombreComercial,responsable,superficie);
		this.cantidadCarpas = cantidadCarpas;
		this.tiempoMontaje = tiempoMontaje;
	}


	public int getCantidadCarpas() {
		return cantidadCarpas;
	}


	public void setCantidadCarpas(int cantidadCarpas) {
		this.cantidadCarpas = cantidadCarpas;
	}


	public int getTiempoMontaje() {
		return tiempoMontaje;
	}


	public void setTiempoMontaje(int tiempoMontaje) {
		this.tiempoMontaje = tiempoMontaje;
	}


	@Override
	public String toString() {
		return "\nPuestoDesarmable [" + super.toString() + "cantidadCarpas=" + cantidadCarpas + ", tiempoMontaje=" + tiempoMontaje + "]";
	}
	
	@Override
	public double calculoDeCanon(Costo costos) {
		double canon = (getSuperficie() * costos.getCostoSuperficie()) - (getTiempoMontaje() * costos.getCostoMontaje());
		return canon;
	}
	
//	Cálculo de Canon: Método que devuelve el monto a pagar por una unidad:
//	● Food Truck: (Superficie * $500) + $2000 si requiere conexión eléctrica.
//	● Puesto: (Superficie * $500) - (Tiempo de Montaje * $10).
}

